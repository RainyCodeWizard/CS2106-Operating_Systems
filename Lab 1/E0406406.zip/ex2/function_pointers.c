/*************************************
* Lab 1 Exercise 2
* Name: H Mohamed Hussain
* Student No: A0199425R
* Lab Group: 10
*************************************/

#include "functions.h"

// write the necessary code to initialize the func_list
// array here, if needed

void update_functions() 
{
    
}
