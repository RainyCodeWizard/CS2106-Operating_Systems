/*************************************
* Lab 1 Exercise 2
* Name: H Mohamed Hussain
* Student No: A0199425R
* Lab Group: 10
*************************************/

//declare your func_list array here
//remember to add in the keyword - extern

void update_functions();
