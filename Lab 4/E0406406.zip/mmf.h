/*************************************
* Lab 4
* Name: H Mohamed Hussain
* Student No: A0199425R
* Lab Group: 10
*************************************/

#include <stddef.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <fcntl.h>

#include <stdio.h>
#include <stdlib.h>

/*
You may define helper structs here,
as long as the functions satisfy the
requirements in the lab document.  If you declare additional names (helper structs or helper functions), they should be prefixed with "mmf_" to avoid potential name clashes.
*/

/*
These functions form the public API of your library.
*/

void *mmf_create_or_open(const char *name, size_t sz);
void mmf_close(void *ptr, size_t sz);
